create table public."Model_Accuracy" (
  id serial not null,
  stock_id integer null,
  model_name character varying null,
  forecast_horizon integer null,
  mse double precision null,
  rmse double precision null,
  mape double precision null,
  r2 double precision null,
  directional_accuracy double precision null,
  created_at date null,
  constraint Model_Accuracy_pkey primary key (id),
  constraint Model_Accuracy_stock_id_fkey foreign KEY (stock_id) references "Stocks" (stock_id)
) TABLESPACE pg_default;